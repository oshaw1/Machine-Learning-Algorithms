
from mlxtend.classifier import StackingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report
from sklearn.ensemble import VotingClassifier
from sklearn import tree
import numpy as np
from load_data import load_data_from_csv
from sklearn.naive_bayes import  GaussianNB

data = load_data_from_csv('C:\\Users\\owent\\Desktop\\tic_tac_toe\\tic-tac-toe.training.csv')
classifier = GaussianNB()
classifier = tree.DecisionTreeClassifier()
classifier.fit(data[1], data[2])
test = load_data_from_csv("C:\\Users\\owent\\Desktop\\tic_tac_toe\\tic-tac-toe.test.csv")
predicted_test_labels = classifier.predict(test[1])
print(predicted_test_labels)

print(classification_report(test[2], predicted_test_labels, digits=3))