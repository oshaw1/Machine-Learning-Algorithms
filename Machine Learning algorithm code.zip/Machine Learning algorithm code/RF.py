# -*- coding: utf-8 -*-
"""
Created on Sun Nov 28 12:43:02 2021

@author: owent
"""

from sklearn.ensemble import RandomForestClassifier
from load_data import load_data_from_csv
from mlxtend.classifier import StackingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report
from sklearn.ensemble import VotingClassifier
from sklearn import tree
import numpy as np


data = load_data_from_csv('C:\\Users\\owent\\Desktop\\tic_tac_toe\\tic-tac-toe.training.csv')
classifier = RandomForestClassifier(n_estimators=100,
                                    max_features=3,
                                    n_jobs=1)
classifier.fit(data[1], data[2])
test = load_data_from_csv("C:\\Users\\owent\\Desktop\\tic_tac_toe\\tic-tac-toe.test.csv")
predicted_test_labels = classifier.predict(test[1])
predicted_test_labels = classifier.predict(test[1])
print(predicted_test_labels)

print(classification_report(test[2], predicted_test_labels, digits=3))